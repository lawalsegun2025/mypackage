# mypackage
This library was creted as an example of how to publish your own Python package.

# How to install
...